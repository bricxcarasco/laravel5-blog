<?php
    header("location:public");
?>